import re
import spacy

nlp = spacy.load("en_core_web_sm")

def extract_named_entities(text):
    doc = nlp(text)
    entities = {
        "name": None,
        "email": None,
        "phone": None,
        "location": None,
    }

    # Extract NAME
    for ent in doc.ents:
        if ent.label_ == "PERSON" and entities["name"] is None:
            entities["name"] = ent.text

    # Extract EMAIL using regex
    email_match = re.search(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+", text)
    if email_match:
        entities["email"] = email_match.group()

    # Extract PHONE using regex
    phone_match = re.search(r"(\+?\d{1,3})?[\s\-]?\(?\d{3,4}\)?[\s\-]?\d{3}[\s\-]?\d{4}", text)
    if phone_match:
        entities["phone"] = phone_match.group()

    # Optional: Extract location
    for ent in doc.ents:
        if ent.label_ == "GPE" and entities["location"] is None:
            entities["location"] = ent.text

    return entities

# Example use:
# resume_text = "..."  # You must pass real resume content here
# entities = extract_named_entities(resume_text)
# print(f"📧 Email: {entities['email']}")
