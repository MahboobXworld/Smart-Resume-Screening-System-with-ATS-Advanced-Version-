# file_manager.py
import os
import shutil
from datetime import datetime

def move_to_shortlisted(resume_path):
    if not os.path.exists("shortlisted"):
        os.makedirs("shortlisted")
    file_name = os.path.basename(resume_path)
    new_path = os.path.join("shortlisted", file_name)
    shutil.copy(resume_path, new_path)
    return new_path

def backup_ranked_csv():
    if not os.path.exists("data"):
        os.makedirs("data")
    src = "data/ranked_candidates.csv"
    if os.path.exists(src):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        shutil.copy(src, f"data/backup_ranked_{timestamp}.csv")

