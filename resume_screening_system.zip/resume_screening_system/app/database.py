# database.py
import sqlite3

DB_NAME = "data/resume_screening.db"

def connect():
    return sqlite3.connect(DB_NAME)

def create_table():
    conn = connect()
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS candidates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT,
        phone TEXT,
        score REAL,
        role TEXT,
        resume_path TEXT
    )''')
    conn.commit()
    conn.close()

def save_candidate(name, email, phone, score, role, resume_path):
    conn = connect()
    cursor = conn.cursor()
    cursor.execute('''INSERT INTO candidates (name, email, phone, score, role, resume_path)
                      VALUES (?, ?, ?, ?, ?, ?)''', (name, email, phone, score, role, resume_path))
    conn.commit()
    conn.close()

def get_top_candidates(limit=3):
    conn = connect()
    cursor = conn.cursor()
    cursor.execute('''SELECT name, email, phone, score, role, resume_path
                      FROM candidates ORDER BY score DESC LIMIT ?''', (limit,))
    results = cursor.fetchall()
    conn.close()
    return results


create_table()
a = get_top_candidates()
print(a)