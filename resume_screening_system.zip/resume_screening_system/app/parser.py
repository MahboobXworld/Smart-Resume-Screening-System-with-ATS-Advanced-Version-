import os
import docx2txt
import textract
from pdfminer.high_level import extract_text as extract_pdf_text

def extract_text_from_pdf(file_path):
    try:
        text = extract_pdf_text(file_path)
        return text
    except Exception as e:
        print(f"Error reading PDF {file_path}: {e}")
        return ""

def extract_text_from_docx(file_path):
    try:
        return docx2txt.process(file_path)
    except Exception as e:
        print(f"Error reading DOCX {file_path}: {e}")
        return ""

def extract_text_from_doc(file_path):
    try:
        text = textract.process(file_path).decode("utf-8")
        return text
    except Exception as e:
        print(f"Error reading DOC {file_path}: {e}")
        return ""

def parse_resume(file_path):
    if file_path.endswith(".pdf"):
        return extract_text_from_pdf(file_path)
    elif file_path.endswith(".docx"):
        return extract_text_from_docx(file_path)
    elif file_path.endswith(".doc"):
        return extract_text_from_doc(file_path)
    else:
        print(f"Unsupported file format: {file_path}")
        return ""

def load_resumes_from_folder(folder_path="resumes"):
    resume_data = {}
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        if os.path.isfile(file_path):
            text = parse_resume(file_path)
            resume_data[filename] = text
    return resume_data
