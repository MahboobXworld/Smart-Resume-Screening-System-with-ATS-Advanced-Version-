'''
# flask_app.py
from flask import Flask, render_template, request, redirect, url_for
import os
from app.main import main

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def upload():
    if request.method == "POST":
        files = request.files.getlist("resumes")
        for f in files:
            f.save(os.path.join("resumes", f.filename))
        return redirect(url_for("results"))
    return render_template("upload.html")

@app.route("/results")
def results():
    ranked = main()
    return render_template("results.html", candidates=ranked)

if __name__ == "__main__":
    app.run(debug=True)
    
    
    
'''
    
    
    
    
    
    
    
    
import os
from flask import Flask, request, render_template
from app.parser import parse_resume
from utils.extractor import extract_email, extract_name, extract_phone
from app.ats_scorer import score_all_resumes

app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/")
def index():
    return render_template("upload.html")

@app.route("/upload", methods=["POST"])
def upload():
    resume_file = request.files["resume"]
    jd_text = request.form["jd"]

    save_path = os.path.join(UPLOAD_FOLDER, resume_file.filename)
    resume_file.save(save_path)

    resume_text = parse_resume(save_path)
    name = extract_name(resume_text)
    email = extract_email(resume_text)
    phone = extract_phone(resume_text)
    score = score_all_resumes(resume_text, jd_text)

    return render_template("results.html", name=name, email=email, phone=phone, score=round(score, 2))

if __name__ == "__main__":
    app.run(debug=True)
