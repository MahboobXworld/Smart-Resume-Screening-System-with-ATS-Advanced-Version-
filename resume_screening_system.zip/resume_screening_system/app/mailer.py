import os
import smtplib
import json
import pandas as pd
import time

from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication

from app.parser import parse_resume
from app.near_extractor import extract_named_entities

def load_email_config(path="config/email_config.json"):
    with open(path, "r") as file:
        return json.load(file)

def send_email(to_address, subject, body, config, attachments=[]):
    msg = MIMEMultipart()
    msg["From"] = f"ATS Recruitment <{config['sender_email']}>"  # ✅ Add friendly sender name
    msg["To"] = to_address
    msg["Subject"] = subject
    msg["Reply-To"] = config['sender_email']
    msg.attach(MIMEText(body, "plain"))

    for file_path in attachments:
        with open(file_path, "rb") as f:
            part = MIMEApplication(f.read(), Name=os.path.basename(file_path))
            part['Content-Disposition'] = f'attachment; filename="{os.path.basename(file_path)}"'
            msg.attach(part)

    try:
        server = smtplib.SMTP(config["smtp_server"], config["smtp_port"])
        server.starttls()
        server.login(config["sender_email"], config["password"])
        server.send_message(msg)
        server.quit()
        print(f"✅ Email sent to {to_address}")
    except Exception as e:
        print(f"❌ Failed to send email to {to_address}: {e}")

def email_top_candidates(score_file="data/ranked_candidates.csv", resumes_dir="resumes", top_n=1):
    config = load_email_config()
    df = pd.read_csv(score_file).head(top_n)

    candidate_summaries = []

    for _, row in df.iterrows():
        filename = row["filename"]
        score = row["score"]
        resume_path = os.path.join(resumes_dir, filename)

        resume_text = parse_resume(resume_path)
        entities = extract_named_entities(resume_text)

        name = entities.get("name", "Candidate")
        email = entities.get("email", None)
        phone = entities.get("phone", "Not found")

        if not email:
            print(f"⚠️ No email found in {filename}, skipping candidate.")
            continue

        candidate_summaries.append({
            "Name": name,
            "Email": email,
            "Phone": phone,
            "Score": score,
            "File": resume_path
        })

        # Email to candidate
        body = f"""Dear {name},

We are pleased to inform you that your resume has been shortlisted based on a match score of {score}% against our job profile.

Our HR team will contact you shortly for the next round of interviews. Please keep your phone and email active.

Warm regards,  
ATS Recruitment Team
"""
        send_email(email, "🎉 Shortlisted for Interview – Congratulations!", body, config)
        time.sleep(3)  # ✅ Delay between emails to avoid spam detection

    # Email to HR with all top 3 resumes and info
    hr_body = f"""Dear HR Team,

Please find below the details of the top {top_n} shortlisted candidates:

"""
    attachments = []

    for c in candidate_summaries:
        hr_body += f"""Name: {c["Name"]}
Email: {c["Email"]}
Phone: {c["Phone"]}
Score: {c["Score"]}%
Resume: Attached as {os.path.basename(c["File"])}

---------------------------
"""
        attachments.append(c["File"])

    hr_body += "\nKindly schedule the interviews and update us with confirmations.\n\nRegards,\nATS System"

    send_email(config["hr_email"], f"Top {top_n} Candidates - Interview Scheduling", hr_body, config, attachments)
