import os
import pandas as pd

from app.parser import  load_resumes_from_folder
from utils.text_cleaner import clean_text
from utils.similarity import calculate_similarity
from app.mailer import email_top_candidates

# Function to load job description
def load_job_description(filepath):
    with open(filepath, "r", encoding="utf-8") as file:
        return file.read()

# Function to save scores to CSV
def save_ranking_to_csv(ranked_data, output_path):
    df = pd.DataFrame(ranked_data)
    df = df.sort_values(by="score", ascending=False)
    df.to_csv(output_path, index=False)
    print(f"📊 Saved ranked candidates to {output_path}")

# Main process
def main():
    print("📥 Loading resumes...")
    resume_folder = "resumes"
    job_desc_file = "data/job_description.txt"

    raw_jd = load_job_description(job_desc_file)
    cleaned_jd = clean_text(raw_jd)

    raw_resumes = load_resumes_from_folder(resume_folder)

    results = []
    for filename, raw_resume in raw_resumes.items():
        cleaned_resume = clean_text(raw_resume)
        score = calculate_similarity(cleaned_resume, cleaned_jd)
        results.append({"filename": filename, "score": round(score * 100, 2)})

    save_ranking_to_csv(results, "data/ranked_candidates.csv")

    email_top_candidates("data/ranked_candidates.csv", resume_folder)

if __name__ == "__main__":
    main()
