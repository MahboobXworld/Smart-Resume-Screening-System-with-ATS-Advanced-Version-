import os
import pandas as pd
from app.parser import load_resumes_from_folder
from utils.text_cleaner import clean_text
from utils.similarity import calculate_similarity

def load_job_description(path="data/job_description.txt"):
    with open(path, "r", encoding="utf-8") as file:
        return file.read()

def score_all_resumes(resume_folder="resumes", output_file="data/ranked_candidates.csv"):
    print("📥 Loading resumes...")
    raw_resumes = load_resumes_from_folder(resume_folder)

    print("🧼 Cleaning job description...")
    job_description = clean_text(load_job_description())

    scored_data = []

    for filename, raw_text in raw_resumes.items():
        print(f"🔍 Scoring resume: {filename}")
        cleaned_resume = clean_text(raw_text)
        score = calculate_similarity(cleaned_resume, job_description)
        scored_data.append({"Resume": filename, "Score (%)": score})

    print("📊 Sorting and saving results...")
    scored_data.sort(key=lambda x: x["Score (%)"], reverse=True)

    df = pd.DataFrame(scored_data)
    df.to_csv(output_file, index=False)
    print(f"✅ Results saved to {output_file}")
