# role_classifier.py
def classify_role(text):
    text = text.lower()
    if "machine learning" in text or "python" in text:
        return "ML Engineer"
    elif "data analysis" in text or "excel" in text:
        return "Data Analyst"
    elif "robotics" in text or "automation" in text:
        return "Robotics Engineer"
    elif "software" in text or "backend" in text:
        return "Software Developer"
    else:
        return "General Role"