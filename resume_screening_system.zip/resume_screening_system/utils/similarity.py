from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def calculate_similarity(resume_text, jd_text):
    vectorizer = TfidfVectorizer()
    vectors = vectorizer.fit_transform([resume_text, jd_text])
    similarity_matrix = cosine_similarity(vectors)
    score = similarity_matrix[0][1]  # similarity between resume and JD
    return score  # returns 0.0 to 1.0
